export * from './PatientRegistration';
export * from './PatientList';
export * from './PatientDetails';
